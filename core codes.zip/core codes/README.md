
A public Python Package for Stochastic Block Model Inference

[https://github.com/funket/pysbm](https://github.com/funket/pysbm)

