class NoFreeNodeException(Exception):
    """Raises if no free node can be found"""
    pass
